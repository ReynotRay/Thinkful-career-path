#### Shopping List

* In this assignment, you'll complete your shopping list app. You'll need to write JavaScript code that handles appending new items to the shopping list and allows users to check off, uncheck and remove items. You will be completing this project independently.

* You'll likely need to use the .val() and .prepend() or .append() methods.

* Adding an event listener to items that don't exist on the page yet can be achieved by including the optional selector parameter to the .on() function.


* adding items .append()
* check off items
* uncheck items
* remove items .prepend()